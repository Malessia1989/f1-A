package it.polito.tdp.formulaone.model;

public class Model {


}
